#pragma once

struct UpdateInfo
{
  UpdateInfo(double dt) : DT(dt) { }
  double DT;
};
